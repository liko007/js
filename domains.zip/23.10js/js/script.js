let colors = ['red', 'green', 'blue', 'yellow', 'black'];

function random (min, max){
	return Math.floor(Math.random()*(max - min +1)) + min;
}


isWin=function(){
	let tdlist = document.querySelectorAll('td');
	for(let i = 0; i < tdlist.length-1; i++) {
		if (tdlist [i].style.background != tdlist[i+1].style.background)
		{
			console.log(tdlist[i].style.background, tdlist[i+1].style.background);
			return false;
		}
	}
	return true;
};

document.querySelector('#set').addEventListener('click', function(){

	
	let rows=document.querySelector('#rows').value;
	let cols=document.querySelector('#cols').value;
	let table = document.querySelector('table');
	let trList = document.querySelectorAll('tr');
	let player = document.querySelector('pl1').value;

	Start = function(){
		

	}
	
	for(let elem of trList){
		elem.remove();
	}
	
	for (let i=1; i <= rows; i++){
		let tr = document.createElement('tr')
		for (let i = 1; i <= cols; i++){
			let td = document.createElement('td');		

			td.addEventListener('click', function(){
				if (colors.indexOf(this.style.background) == colors.length-1)
					this.style.background=colors[0];
				else
					this.style.background=colors[colors.indexOf(this.style.background)+1];

				if (isWin())
					alert('win');

			});
			 
			setTimeout(function(){
				tr.appendChild(td).style.background=colors[random(0, colors.length-1)];}, i*200)
		}
		setTimeout(function(){
			table.appendChild(tr);}, i*200);
			
	}
});



